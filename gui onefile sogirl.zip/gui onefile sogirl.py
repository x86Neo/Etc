# coding: utf8
import os
import shutil
import subprocess
import time
import requests
import re
import json
from urllib.parse import urljoin
import threading

# GUI 라이브러리
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from concurrent.futures import ThreadPoolExecutor, as_completed

# --- 설정 ---
MAX_WORKERS = 8
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'

# --- 핵심 함수 ---

def setup_driver():
    """undetected-chromedriver를 설정하고 네트워크 로깅을 활성화합니다."""
    try:
        options = uc.ChromeOptions()
        options.add_argument(f'user-agent={USER_AGENT}')
        options.set_capability('goog:loggingPrefs', {'performance': 'ALL'})
        driver = uc.Chrome(options=options, use_subprocess=True)
        return driver
    except Exception as e:
        raise Exception(f"undected-chromedriver 초기화 실패: {e}")

def find_video_info(driver, url, session, status_callback):
    """네트워크 로그에서 '중간 다리'를 찾고, 그곳에서 최종 m3u8 주소를 추출합니다."""
    status_callback("페이지 접속 및 수동 인증 대기 중...")
    driver.get(url)

    messagebox.showinfo("사용자 인증 필요", 
        "브라우저 창이 열렸습니다. (탐지 우회 모드)\n\n"
        "1. Cloudflare 인증(체크박스 클릭 등)을 완료하세요.\n"
        "2. 동영상 플레이어의 재생(▶) 버튼을 반드시 한번 클릭하세요.\n\n"
        "모든 준비가 완료되면 이 확인 창을 닫아주세요."
    )
    status_callback("수동 조작 완료. 네트워크 로그 분석 중...")
    
    try:
        title = driver.title.split(' - ')[0]
        title = re.sub(r'[\\/*?:"<>|]', "", title)
    except Exception:
        title = 'video'
    
    logs = driver.get_log('performance')
    embed_url = None
    for entry in logs:
        log = json.loads(entry['message'])['message']
        if 'Network.requestWillBeSent' in log['method'] and 'request' in log['params']:
            request_url = log['params']['request']['url']
            if 'iframe.mediadelivery.net/embed/' in request_url:
                embed_url = request_url
                break
    if not embed_url: raise Exception("'mediadelivery.net/embed/' 중간 다리 주소 탐색 실패")

    r = session.get(embed_url, headers={'Referer': url})
    r.raise_for_status()
    match = re.search(r'"(https?://[^"]+\.m3u8)"', r.text)
    if not match: raise Exception("'중간 다리' 페이지에서 최종 m3u8 주소 추출 실패")
    
    final_m3u8_url = match.group(1)
    status_callback("동영상 정보 획득 완료!")
    return title, final_m3u8_url, embed_url

def get_best_m3u8(playlist_url, referer, session):
    headers = {'Referer': referer}
    r = session.get(playlist_url, headers=headers); r.raise_for_status()
    base_url = playlist_url.rsplit('/', 1)[0]
    if "#EXT-X-STREAM-INF" not in r.text: return playlist_url
    best_resolution, best_url = 0, ""
    lines = r.text.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("#EXT-X-STREAM-INF"):
            match = re.search(r'RESOLUTION=(\d+)x(\d+)', line)
            if match and int(match.group(2)) > best_resolution:
                best_resolution, best_url = int(match.group(2)), lines[i+1]
    return urljoin(playlist_url, best_url) if best_url else None

def download_and_decrypt_segment(args):
    """(★★★★★ 최종 수정 ★★★★★) 암호 해독(복호화) 로직을 수정합니다."""
    segment_url, key, iv, session, temp_dir, index, total = args
    try:
        r = session.get(segment_url, timeout=30); r.raise_for_status()
        decrypted_data = r.content
        if key:
            # M3U8에 명시된 IV를 사용하지 않고, 항상 세그먼트의 순번을 IV로 사용.
            # 이것이 더 표준적이고 안정적인 방식임.
            segment_iv = index.to_bytes(16, 'big') 
            decryptor = Cipher(algorithms.AES(key), modes.CBC(segment_iv), backend=default_backend()).decryptor()
            decrypted_data = decryptor.update(r.content) + decryptor.finalize()
        filepath = os.path.join(temp_dir, f"{index:05d}.ts")
        with open(filepath, 'wb') as f: f.write(decrypted_data)
        return True, index
    except Exception as e:
        # 상세 오류 출력을 위해 e를 포함시킴
        return False, f"인덱스 {index} 오류: {e}"

def concatenate_segments(temp_dir, output_path):
    list_file_path = os.path.join(temp_dir, 'filelist.txt')
    with open(list_file_path, 'w', encoding='utf-8') as f:
        for ts_file in sorted(os.listdir(temp_dir)):
            if ts_file.endswith('.ts'): f.write(f"file '{ts_file}'\n")
    command = ['ffmpeg', '-y', '-f', 'concat', '-safe', '0', '-i', 'filelist.txt', '-c', 'copy', output_path]
    subprocess.run(command, check=True, capture_output=True, encoding='utf-8', errors='ignore',
                   creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0, cwd=temp_dir)


class DownloaderApp:
    def __init__(self, root):
        self.root = root
        self.root.title("SoGirl 다운로더 v1.1")
        self.root.geometry("500x250")
        self.root.resizable(False, False)

        frame = ttk.Frame(self.root, padding="10")
        frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)

        ttk.Label(frame, text="동영상 주소:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.url_var = tk.StringVar()
        self.url_entry = ttk.Entry(frame, textvariable=self.url_var, width=50)
        self.url_entry.grid(row=0, column=1, columnspan=2, sticky=(tk.W, tk.E))

        ttk.Label(frame, text="저장 위치:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.path_var = tk.StringVar(value=os.path.join(os.path.expanduser("~"), "Downloads"))
        self.path_entry = ttk.Entry(frame, textvariable=self.path_var, width=40)
        self.path_entry.grid(row=1, column=1, sticky=(tk.W, tk.E))
        self.browse_button = ttk.Button(frame, text="찾아보기", command=self.browse_folder)
        self.browse_button.grid(row=1, column=2, sticky=tk.W)

        self.download_button = ttk.Button(frame, text="다운로드 시작", command=self.start_download_thread)
        self.download_button.grid(row=2, column=0, columnspan=3, pady=10)

        self.progress_var = tk.DoubleVar()
        self.progress_bar = ttk.Progressbar(frame, variable=self.progress_var, maximum=100)
        self.progress_bar.grid(row=3, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=5)
        
        self.status_var = tk.StringVar(value="대기 중...")
        self.status_label = ttk.Label(frame, textvariable=self.status_var, wraplength=480)
        self.status_label.grid(row=4, column=0, columnspan=3, sticky=tk.W, pady=5)

        frame.columnconfigure(1, weight=1)

    def browse_folder(self):
        folder = filedialog.askdirectory()
        if folder: self.path_var.set(folder)

    def start_download_thread(self):
        url, path = self.url_var.get(), self.path_var.get()
        if not url or not path:
            messagebox.showerror("오류", "주소와 저장 위치를 모두 입력해야 합니다."); return

        self.download_button.config(state="disabled")
        self.progress_var.set(0)
        threading.Thread(target=self.download_worker, args=(url, path), daemon=True).start()

    def update_status(self, message):
        self.root.after(0, lambda: self.status_var.set(message))

    def update_progress(self, value):
        self.root.after(0, lambda: self.progress_var.set(value))

    def download_worker(self, target_url, download_dir):
        driver, temp_dir = None, None
        try:
            self.update_status("초기화 중..."); driver = setup_driver()
            session = requests.Session(); session.headers.update({'User-Agent': USER_AGENT})
            
            title, master_playlist_url, embed_url = find_video_info(driver, target_url, session, self.update_status)

            self.update_status("인증 정보(쿠키) 동기화 중...")
            for cookie in driver.get_cookies():
                session.cookies.set(cookie['name'], cookie['value'], domain=cookie['domain'])
            session.headers.update({'Referer': embed_url})
            
            playlist_url = get_best_m3u8(master_playlist_url, embed_url, session)
            self.update_status(f"최종 플레이리스트: {playlist_url}")

            r = session.get(playlist_url); r.raise_for_status()
            m3u8_content = r.text
            
            key, iv = None, None
            key_match = re.search(r'#EXT-X-KEY:METHOD=AES-128,URI="([^"]+)"(?:,IV=0x([0-9a-fA-F]+))?', m3u8_content)
            if key_match:
                self.update_status("암호화 키 가져오는 중...")
                key_url, iv_hex = key_match.groups()
                key_url = urljoin(playlist_url, key_url)
                if iv_hex: iv = bytes.fromhex(iv_hex)
                key_res = session.get(key_url); key_res.raise_for_status(); key = key_res.content
            
            segments = [urljoin(playlist_url, line) for line in m3u8_content.splitlines() if line and not line.startswith('#')]
            total_segments = len(segments)
            self.update_status(f"총 {total_segments}개 영상 조각 다운로드 시작...")
            
            temp_dir = os.path.join(download_dir, f"temp_{title.replace(' ', '_')}")
            os.makedirs(temp_dir, exist_ok=True)
            
            tasks = [(url, key, iv, session, temp_dir, i, total_segments) for i, url in enumerate(segments)]
            
            downloaded_count = 0
            with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
                future_to_task = {executor.submit(download_and_decrypt_segment, task): task for task in tasks}
                for future in as_completed(future_to_task):
                    success, result_info = future.result()
                    if success:
                        downloaded_count += 1
                        progress = (downloaded_count / total_segments) * 100
                        self.update_progress(progress)
                        self.update_status(f"다운로드 중... {downloaded_count} / {total_segments}")
                    else:
                        raise Exception(f"세그먼트 다운로드 실패. 원인: {result_info}")

            self.update_status("파일 합치는 중...")
            output_path = os.path.join(download_dir, f"{title}.mp4")
            concatenate_segments(temp_dir, output_path)
            
            self.update_status("완료!")
            messagebox.showinfo("성공", f"다운로드를 완료했습니다!\n파일 위치: {output_path}")

        except Exception as e:
            self.update_status(f"오류 발생")
            messagebox.showerror("오류 발생", f"작업 중 오류가 발생했습니다:\n{e}")
        finally:
            if driver: driver.quit()
            if temp_dir and os.path.exists(temp_dir): shutil.rmtree(temp_dir)
            self.root.after(0, lambda: self.download_button.config(state="normal"))
            self.root.after(0, lambda: self.update_progress(0))

if __name__ == "__main__":
    root = tk.Tk()
    app = DownloaderApp(root)
    root.mainloop()
