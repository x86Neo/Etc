# coding: utf8
import os
import shutil
import subprocess
import time
import requests
import re
import json
from urllib.parse import urljoin

import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from concurrent.futures import ThreadPoolExecutor, as_completed

# --- 설정 ---
MAX_WORKERS = 8
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'

# --- 핵심 함수 ---

def setup_driver():
    """undetected-chromedriver를 설정하고 네트워크 로깅을 활성화합니다."""
    print(">>> undetected-chromedriver 초기화를 시도합니다...")
    try:
        options = uc.ChromeOptions()
        options.add_argument(f'user-agent={USER_AGENT}')
        options.set_capability('goog:loggingPrefs', {'performance': 'ALL'})
        driver = uc.Chrome(options=options, use_subprocess=True)
        print(">>> ✅ undetected-chromedriver가 성공적으로 초기화되었습니다.")
        return driver
    except Exception as e:
        print(f"\n[치명적 오류] undetected-chromedriver 초기화에 실패했습니다: {e}")
        return None

def find_video_info(driver, url, session):
    """네트워크 로그에서 '중간 다리'를 찾고, 그곳에서 최종 m3u8 주소를 추출합니다."""
    print(">>> 페이지에 접속하여 영상 정보를 로드합니다...")
    driver.get(url)

    print("\n" + "="*60)
    print(">>> 브라우저 창이 열렸습니다. (탐지 우회 모드)")
    print(">>> 1. Cloudflare 인증(체크박스 클릭 등)을 완료하세요.")
    print(">>> 2. 동영상 플레이어의 재생(▶) 버튼을 반드시 한번 클릭하세요.")
    print(">>> 3. 모든 준비가 완료되면, 이 창으로 돌아와 Enter를 누르세요.")
    print("\n[중요] 다운로드가 모두 끝날 때까지 절대로 브라우저 창을 닫지 마세요!")
    input("="*60 + "\n")
    print(">>> 수동 조작 완료. 네트워크 로그 분석을 시작합니다...")

    try:
        title = driver.title.split(' - ')[0]
        title = re.sub(r'[\\/*?:"<>|]', "", title)
    except Exception:
        title = 'video'
    print(f"    - 영상 제목: {title}")

    try:
        logs = driver.get_log('performance')
        embed_url = None
        for entry in logs:
            log = json.loads(entry['message'])['message']
            if 'Network.requestWillBeSent' in log['method'] and 'request' in log['params']:
                request_url = log['params']['request']['url']
                if 'iframe.mediadelivery.net/embed/' in request_url:
                    embed_url = request_url
                    break
        
        if not embed_url:
            print("    [에러] 네트워크 로그에서 'mediadelivery.net/embed/' 중간 다리 주소를 찾지 못했습니다.")
            return None, None, None

        print(">>> ✅ '중간 다리' 주소 발견! 최종 m3u8 주소를 추출합니다...")
        r = session.get(embed_url, headers={'Referer': url})
        r.raise_for_status()
        
        match = re.search(r'"(https?://[^"]+\.m3u8)"', r.text)
        if not match:
            print("    [에러] '중간 다리' 페이지에서 최종 m3u8 주소를 추출하지 못했습니다.")
            return None, None, None
            
        final_m3u8_url = match.group(1)
        print(">>> ✅ 최종 m3u8 주소 추출 성공!")
        return title, final_m3u8_url, embed_url

    except Exception as e:
        print(f"    [에러] 로그 분석 또는 최종 주소 추출 중 오류가 발생했습니다: {e}")
        return None, None, None

def get_best_m3u8(playlist_url, referer, session):
    headers = {'Referer': referer}
    try:
        r = session.get(playlist_url, headers=headers); r.raise_for_status()
    except requests.exceptions.RequestException as e:
        print(f"\n[에러] m3u8 플레이리스트를 가져오는 데 실패했습니다: {e}"); return None
    base_url = playlist_url.rsplit('/', 1)[0]
    if "#EXT-X-STREAM-INF" not in r.text: return playlist_url
    best_resolution, best_url = 0, ""
    lines = r.text.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("#EXT-X-STREAM-INF"):
            match = re.search(r'RESOLUTION=(\d+)x(\d+)', line)
            if match and int(match.group(2)) > best_resolution:
                best_resolution, best_url = int(match.group(2)), lines[i+1]
    return urljoin(playlist_url, best_url) if best_url else None

def download_and_decrypt_segment(args):
    segment_url, key, iv, session, temp_dir, index, total = args
    try:
        r = session.get(segment_url, timeout=30); r.raise_for_status()
        decrypted_data = r.content
        if key:
            segment_iv = iv if iv else index.to_bytes(16, 'big')
            decryptor = Cipher(algorithms.AES(key), modes.CBC(segment_iv), backend=default_backend()).decryptor()
            decrypted_data = decryptor.update(r.content) + decryptor.finalize()
        filepath = os.path.join(temp_dir, f"{index:05d}.ts")
        with open(filepath, 'wb') as f: f.write(decrypted_data)
        return True
    except Exception as e:
        print(f"\n[세그먼트 처리 오류] 인덱스 {index} (URL: {segment_url})\n    오류 원인: {e}")
        return False

def concatenate_segments(temp_dir, output_path):
    print("\n>>> 다운로드 완료. 이제 파일들을 하나로 합칩니다 (ffmpeg 사용)...")
    list_file_path = os.path.join(temp_dir, 'filelist.txt')
    with open(list_file_path, 'w', encoding='utf-8') as f:
        for ts_file in sorted(os.listdir(temp_dir)):
            if ts_file.endswith('.ts'): f.write(f"file '{ts_file}'\n")
            
    command = ['ffmpeg', '-y', '-f', 'concat', '-safe', '0', '-i', 'filelist.txt', '-c', 'copy', output_path]
    try:
        # (★★★★★ 최종 수정 ★★★★★) ffmpeg 출력 인코딩을 'utf-8'로 명시하여 오류 방지
        subprocess.run(command, check=True, capture_output=True, 
                       encoding='utf-8', errors='ignore',
                       creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0,
                       cwd=temp_dir)
        print(f"\n>>> 💯 성공! 영상이 다음 경로에 저장되었습니다: {output_path}")
    except subprocess.CalledProcessError as e:
        # 실패 시 에러 내용만 출력하도록 개선
        print(f"\n[에러] ffmpeg 실행 중 오류가 발생했습니다.\n    - 출력: {e.stderr}")
    except FileNotFoundError:
        print("\n[에러] ffmpeg가 설치되어 있지 않거나 PATH에 등록되어 있지 않습니다.")


def main():
    target_url = input(">>> 다운로드할 sogirl.so 영상 주소를 입력하세요: ")
    if "sogirl.so" not in target_url: print("[오류] 유효한 sogirl.so 주소가 아닙니다."); return
    default_path = os.path.join(os.path.expanduser("~"), "Downloads")
    download_dir = input(f">>> 저장할 폴더 경로를 입력하세요 (기본값: {default_path}): ") or default_path
    driver, temp_dir = None, None
    try:
        driver = setup_driver()
        if not driver: print(">>> 드라이버 생성 실패로 프로그램을 종료합니다."); return
        session = requests.Session()
        session.headers.update({'User-Agent': USER_AGENT})
        
        title, master_playlist_url, embed_url = find_video_info(driver, target_url, session)
        if not (title and master_playlist_url and embed_url): return

        print(">>> [알림] 브라우저의 인증 정보(쿠키)를 동기화합니다...")
        for cookie in driver.get_cookies():
            session.cookies.set(cookie['name'], cookie['value'], domain=cookie['domain'])
        session.headers.update({'Referer': embed_url})
        
        playlist_url = get_best_m3u8(master_playlist_url, embed_url, session)
        if not playlist_url: print("[에러] 유효한 하위 플레이리스트를 찾지 못했습니다."); return
        print(f"    - 최종 플레이리스트: {playlist_url}")

        r = session.get(playlist_url); r.raise_for_status()
        m3u8_content = r.text
        
        key, iv = None, None
        key_match = re.search(r'#EXT-X-KEY:METHOD=AES-128,URI="([^"]+)"(?:,IV=0x([0-9a-fA-F]+))?', m3u8_content)
        if key_match:
            key_url, iv_hex = key_match.groups()
            key_url = urljoin(playlist_url, key_url)
            if iv_hex: iv = bytes.fromhex(iv_hex)
            print(">>> 암호화 키를 가져옵니다..."); key_res = session.get(key_url); key_res.raise_for_status(); key = key_res.content
            print("    - 키 획득 완료.")
        else: print("    - 암호화되지 않은 영상입니다.")
        
        segments = [urljoin(playlist_url, line) for line in m3u8_content.splitlines() if line and not line.startswith('#')]
        total_segments = len(segments)
        if not segments: print("[에러] m3u8 파일에서 영상 조각(.ts)을 찾을 수 없습니다."); return
        print(f">>> 총 {total_segments}개의 영상 세그먼트를 다운로드합니다.")
        
        temp_dir = os.path.join(download_dir, f"temp_{title.replace(' ', '_')}")
        os.makedirs(temp_dir, exist_ok=True)
        
        tasks = [(url, key, iv, session, temp_dir, i, total_segments) for i, url in enumerate(segments)]
        
        downloaded_count = 0
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
            future_to_task = {executor.submit(download_and_decrypt_segment, task): task for task in tasks}
            for future in as_completed(future_to_task):
                if future.result():
                    downloaded_count += 1
                    if downloaded_count % 50 == 0 or downloaded_count == total_segments:
                        print(f"    - 다운로드 진행: {downloaded_count} / {total_segments}")
                else:
                    executor.shutdown(wait=False, cancel_futures=True)
                    raise Exception("Segment download failed")

        if downloaded_count != total_segments: print("\n[에러] 일부 세그먼트가 누락되었습니다. 합치기 작업을 중단합니다."); return
        
        output_path = os.path.join(download_dir, f"{title}.mp4")
        concatenate_segments(temp_dir, output_path)
    
    except Exception as e:
        print(f"\n작업 중단: {e}")
    finally:
        if driver:
            print("\n>>> 모든 작업이 완료되었습니다. 이제 브라우저를 닫아도 좋습니다.")
            driver.quit()
        if temp_dir and os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)
        print(">>> 프로그램 종료.")

if __name__ == "__main__":
    main()
